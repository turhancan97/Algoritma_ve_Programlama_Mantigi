
public class Merhaba_dunya {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Java ile Merhaba D�nya!");
	}

}




