// Mant�ksal Operat�rler
#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
int main()
{
	int a = 30;
	int b = 40;
	
	cout << "A esit mi B " << (a==b) << endl;
	cout << "A esit degil mi B " << (a!=b) << endl;
	cout << "A buyuk B " << (a>b) << endl;
	cout << "A kucuk B " << (a<b) << endl;
}
