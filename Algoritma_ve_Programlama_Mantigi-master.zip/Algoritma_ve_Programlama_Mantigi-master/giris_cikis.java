import java.util.Scanner;
public class giris_cikis {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		
		int tamSayi;
		double ondaliksayi;
		String kelime;
		
		tamSayi = scn.nextInt();
		ondaliksayi = scn.nextDouble(); 
		kelime = scn.next();
		
		System.out.println(tamSayi);
		System.out.println(ondaliksayi);
		System.out.println(kelime);
		
		
	}

}
