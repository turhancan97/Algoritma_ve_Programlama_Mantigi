#include<stdio.h>
int main()
{
	printf("C++ ile Merhaba Dunya!");
}

