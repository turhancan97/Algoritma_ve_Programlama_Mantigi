import java.util.Scanner;
public class mantiksal_operator {

	public static void main(String[] args) {
		int a = 30;
		int b = 40
				;
		System.out.println("A esit mi B " + (a==b));
		System.out.println("A esit degil mi B " + (a!=b));
		System.out.println("A buyuk B " + (a>b));
		System.out.println("A kucuk B " + (a<b));

	}

}
